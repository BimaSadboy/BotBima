CARA INSTALL MELALUI GITCLONE

> pkg install git
> gitclone https://github.com/ItsAraZ/Arabot
> cd arabot
> bash install.sh
> npm start
> scan qr

CARA INSTALL

> termux-setup-storage [Y]
> cd /sdcard
> cd -r arabot /$HOME
> cd arabot
> bash install.sh 
> npm start
> Now scan the QR
